import java.util.Scanner;

import factory.CanvasServiceFactory;

public class CanvasClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String command = "";
		
		try {
			while (!command.equals("Q")) {
				System.out.print("Enter command:");
				command = scan.nextLine();
				//parser.parse(command);
				CanvasServiceFactory.getService().run(command);
			}
			System.out.println("Program Exited!");
		} finally {
			scan.close();
		}
		
	}

}
