package factory;

import services.CanvasService;
import services.CanvasServiceImpl;
import utils.CommandParser;

public class CanvasServiceFactory {

	static CanvasService canvasService= null ; 
	
	public static CanvasService getService(){
		
		if(canvasService==null){
			canvasService = new CanvasServiceImpl(new CommandParser());
		}
		return canvasService;
	}
}
