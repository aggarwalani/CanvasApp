package utils;

public class CanvasConstants {

	public static final String SPACE = " ";
	public static final char Pixel = '*';
	public static final char TopBorder = '-';
	public static final char SideBorder = '|';
	public static final char FILLCharcter = 'x';
}
