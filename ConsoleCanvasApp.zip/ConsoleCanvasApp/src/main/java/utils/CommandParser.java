package utils;

import models.Canvas;

public class CommandParser {

	Canvas canvas;

	public boolean parse(String command){

		char ch = command.charAt(0);
		String[] cmd;
		try {
			switch (ch) {
			case 'C':
				cmd = command.split(CanvasConstants.SPACE);
				if(cmd.length<3) {
					System.err.println("Invalid command. Try again!!\n");
					return false;
					//throw new Exception("Invalid Command");
				}
				canvas = new Canvas(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]));
				canvas.draw();
				break;
			case 'L':
				cmd = command.split(CanvasConstants.SPACE);
				if (canvas == null) {
					System.err.println("Draw a canvas first");
					return false;
				}
				
				if(!isValidCommandLine(cmd)){
					System.err.println("Invalid command. Try again!!\n");
					return false;
				}
				canvas.drawLine(Integer.parseInt(cmd[1]),
						Integer.parseInt(cmd[2]), Integer.parseInt(cmd[3]),
						Integer.parseInt(cmd[4]), 'X');
				canvas.draw();
				break;
			case 'R':
				cmd = command.split(CanvasConstants.SPACE);
				if (canvas == null) {
					System.err.println("Draw a canvas first");
					return false;
				}
				
				if(!isValidCommandRectangle(cmd)){
					System.err.println("Invalid command. Try again!!\n");
					return false;
				}
				canvas.drawRectangle(Integer.parseInt(cmd[1]),
						Integer.parseInt(cmd[2]), Integer.parseInt(cmd[3]),
						Integer.parseInt(cmd[4]), 'X');
				canvas.draw();
				break;
			case 'B':
				cmd = command.split(CanvasConstants.SPACE);
				if (canvas == null) {
					System.err.println("Draw a canvas first");
					return false;
				}
				
				if(!isValidCommandBucketFill(cmd)){
					System.err.println("Invalid command. Try again!!\n");
					return false;
				}
				canvas.bucketFill(Integer.parseInt(cmd[1]),
						Integer.parseInt(cmd[2]), cmd[3].charAt(0));
				canvas.draw();
				break;
				
			default:
				System.err.println("Invalid command. Try again!!\n");
				return false;
			
			
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid command. Try again!!\n");
		} catch (Exception e) {
			System.out.println("Error Occured\n");
			e.printStackTrace();
			System.exit(1);
		}
		return true;
	}
	
	private boolean isValidCommandLine(String[] cmd) {
		if(cmd.length<5) {
			return false;
		} else {
			return true;
		}
	}

	private boolean isValidCommandRectangle(String[] cmd) {
		if(cmd.length<5) {
			return false;
		} else {
			return true;
		}
	}
	private boolean isValidCommandBucketFill(String[] cmd) {
		if(cmd.length<4) {
			return false;
		} else {
			return true;
		}
	}
}
