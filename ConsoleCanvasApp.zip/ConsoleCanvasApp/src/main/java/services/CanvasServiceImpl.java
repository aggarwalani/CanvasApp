package services;

import models.Canvas;
import utils.CommandParser;

public class CanvasServiceImpl implements CanvasService{
	
	Canvas canvas= null ; 
	CommandParser parser = null;
	public CanvasServiceImpl(CommandParser parser,Canvas canvas){
		this.canvas = canvas;
		this.parser = parser;
		
	}
	public CanvasServiceImpl(CommandParser parser){
		this.parser = parser;
		
	}
	public void run(String command) {
		parser.parse(command);
		
	}



}
