package services;

public interface CanvasService {
	

	public abstract void run(String command);

}
