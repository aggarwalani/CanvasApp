import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import services.CanvasService;
import services.CanvasServiceImpl;
import utils.CommandParser;


public class CommandParserTest {

	CommandParser parser = null ; 
	CanvasService service;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() {
		parser = new CommandParser();
		service = new CanvasServiceImpl(parser);
		
		String command="C 10";// TO create Canvas
		
		//System.out.println("Test case-1 Invalid Command to create canvas:" + command);
		//assertFalse(parser.parse(command));
		
		command ="C 20 4";
		System.out.println("Command to create canvas:" + command);
		assertTrue(parser.parse(command));
		
		
		command ="L 1 2 6";
		System.out.println("Test case-3 Invalid Command to create line:" + command);
		assertFalse(parser.parse(command));
		
		
		command ="L 1 2 6 2";
		System.out.println("Command to create line:" + command);
		assertTrue(parser.parse(command));

		command ="L 6 3 6 4";
		System.out.println("Command to create line:" + command);
		assertTrue(parser.parse(command));
		
		command ="R 14 1 18";
		//System.out.println("Test case-5 Invalid Command to create Rectangle:" + command);
		//assertFalse(parser.parse(command));
		
		
		command ="R 14 1 18 3";
		System.out.println("Command to create Rectangle:" + command);
		assertTrue(parser.parse(command));
	
		command ="B 10 3 o";
		System.out.println("Command to Fill:" + command);
		assertTrue(parser.parse(command));
		
		command ="L 6 4 13 4";
		System.out.println("Command to create Line:" + command);
		assertTrue(parser.parse(command));
		
		command ="B 1 2 *";
		System.out.println("Command to Fill:" + command);
		assertTrue(parser.parse(command));
	}

}
